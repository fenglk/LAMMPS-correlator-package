/* -*- c++ -*- ----------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

#ifdef DUMP_CLASS

DumpStyle(ocf, DumpOCF)

#else

#ifndef LMP_DUMP_OCF_H
#define LMP_DUMP_OCF_H

#include <stdio.h>
#include <cmath>
#include "dump.h"
#include "macros_flk.h"

class FCorrelator
{
public:
	/** Constructor */
	FCorrelator() { numcorrelators = 0; };
	FCorrelator(const unsigned int numcorrin, const unsigned int pin, const unsigned int min, unsigned int ninput);
	~FCorrelator();

	
	double *t, *f;
	unsigned int npcorr;

	unsigned int ni; /// ninput

	/** Accumulated result of incoming values **/
	//double accval;
	double *accval;
	double dr;

	/** Set size of correlator */
	void setsize(const unsigned int numcorrin = 32, const unsigned int pin = 16, const unsigned int min = 2, unsigned int ninput = 0);

	/** Add a scalar/vector to the correlator number k */
	//void add(const VecR w[nMID], const unsigned int k = 0);
	void add(double *w, const unsigned int k = 0);

	/** Evaluate the current state of the correlator */
	void evaluate(const bool norm = false);

	/** Initialize all values (current and average) to zero */
	void initialize();



private:
	/** Points per correlator */
	unsigned int p;
	/** Number of points over which to average; RECOMMENDED: p mod m = 0 */
	unsigned int m;
	/** Number of Correlators */
	unsigned int numcorrelators;



	/** Where the coming values are stored */
	double ***shift; //nMID
	/** Array containing the actual calculated correlation function */
	double **correlation;
	/** Number of values accumulated in cor */
	unsigned long int **ncorrelation;

	/** Accumulator in each correlator */
	double **accumulator; //nMID
	/** Index that controls accumulation in each correlator */
	unsigned int *naccumulator;
	/** Index pointing at the position at which the current value is inserted */
	unsigned int *insertindex;



	/** Minimum distance between points for correlators k>0; dmin = p/m */
	unsigned int dmin;

	/*  SCHEMATIC VIEW OF EACH CORRELATOR
	p=N
	<----------------------------------------------->
	_________________________________________________
	|0|1|2|3|.|.|.| | | | | | | | | | | | | | | |N-1|
	-------------------------------------------------
	*/

	/** Lenght of result arrays */
	unsigned int length;
	/** Maximum correlator attained during simulation */
	unsigned int kmax;

};

class FCorrelatorMSD
{
public:
	FCorrelatorMSD() { numcorrelators = 0; };
	FCorrelatorMSD(const unsigned int numcorrin, const unsigned int pin, const unsigned int min, unsigned int ninput);
	~FCorrelatorMSD();

	
	double *t, *f;
	unsigned int npcorr;

	unsigned int ni;

	/** Accumulated result of incoming values **/
	//double accval;
	flkVecR *accval;
	flkVecR dr;

	/** Set size of correlator */
	void setsize(const unsigned int numcorrin = 32, const unsigned int pin = 16, const unsigned int min = 2, unsigned int ninput = 0);

	/** Add a scalar/vector to the correlator number k */
	//void add(const VecR w[nMID], const unsigned int k = 0);
	void add(flkVecR *w, const unsigned int k = 0);

	/** Evaluate the current state of the correlator */
	void evaluate(const bool norm = false);

	/** Initialize all values (current and average) to zero */
	void initialize();

private:

	/** Points per correlator */
	unsigned int p;
	/** Number of points over which to average; RECOMMENDED: p mod m = 0 */
	unsigned int m;
	/** Number of Correlators */
	unsigned int numcorrelators;



	/** Where the coming values are stored */
	flkVecR ***shift; //nMID
	/** Array containing the actual calculated correlation function */
	double **correlation;
	/** Number of values accumulated in cor */
	unsigned long int **ncorrelation;

	/** Accumulator in each correlator */
	flkVecR **accumulator; //nMID
	/** Index that controls accumulation in each correlator */
	unsigned int *naccumulator;
	/** Index pointing at the position at which the current value is inserted */
	unsigned int *insertindex;

	unsigned int dmin;

	/** Lenght of result arrays */
	unsigned int length;
	/** Maximum correlator attained during simulation */
	unsigned int kmax;
};


class FCorrelatorACF
{
public:
	FCorrelatorACF() { numcorrelators = 0; };
	FCorrelatorACF(const unsigned int numcorrin, const unsigned int pin, const unsigned int min, unsigned int ninput);
	~FCorrelatorACF();

	double *t, *f;
	unsigned int npcorr;

	unsigned int ni;
	/** Accumulated result of incoming values **/
	//double accval;
	flkVecR *accval;
	flkVecR dr;

	/** Set size of correlator */
	void setsize(const unsigned int numcorrin = 32, const unsigned int pin = 16, const unsigned int min = 2, unsigned int ninput = 0);

	/** Add a scalar/vector to the correlator number k */
	//void add(const VecR w[nMID], const unsigned int k = 0);
	void add(flkVecR *w, const unsigned int k = 0);

	/** Evaluate the current state of the correlator */
	void evaluate(const bool norm = false);

	/** Initialize all values (current and average) to zero */
	void initialize();

private:
	/** Points per correlator */
	unsigned int p;
	/** Number of points over which to average; RECOMMENDED: p mod m = 0 */
	unsigned int m;
	/** Number of Correlators */
	unsigned int numcorrelators;

	/** Where the coming values are stored */
	flkVecR ***shift; //nMID
	/** Array containing the actual calculated correlation function */
	double **correlation;
	/** Number of values accumulated in cor */
	unsigned long int **ncorrelation;

	/** Accumulator in each correlator */
	flkVecR **accumulator; //nMID
	/** Index that controls accumulation in each correlator */
	unsigned int *naccumulator;
	/** Index pointing at the position at which the current value is inserted */
	unsigned int *insertindex;

	unsigned int dmin;

	/** Lenght of result arrays */
	unsigned int length;
	/** Maximum correlator attained during simulation */
	unsigned int kmax;

};





























namespace LAMMPS_NS {

	class DumpOCF : public Dump, public FCorrelator, public FCorrelatorMSD, public FCorrelatorACF {
	public:
		DumpOCF(class LAMMPS *, int, char**);
		virtual ~DumpOCF();

		flkVecR *xatoms; /// all postions in 1 frame
		int indexAtom;
		unsigned int i1, i2;
		int countMol;



		/// test class FCorrelator OCF: 
		FILE *OCF;
		FILE *OCFALL;
		FCorrelator Sxy, Sxz, Syz, Sxy1, Sxz1, Syz1, Sxy2, Sxz2, Syz2, Axy1, Axz1, Ayz1, Axy2, Axz2, Ayz2;
		double nBond1, nBond2, nBond;
		double phi1, phi2; /// volume fraction for 1 and 2 components
		double **OTC1, **OTC2;
		double **OTC12;
		double **SumOTC1, **SumOTC2;
		double **SumOTC;
		flkVecR BondVector;
		double Bondlength;
		double st, s1, s2, a1, a2, c1, c2, c12, kappa;

		/// normalized by its length: 
		FILE *nOCF;
		FILE *nOCFALL;
		FCorrelator nSxy, nSxz, nSyz, nSxy1, nSxz1, nSyz1, nSxy2, nSxz2, nSyz2, nAxy1, nAxz1, nAyz1, nAxy2, nAxz2, nAyz2;
		double **nOTC1, **nOTC2;
		double **nOTC12;
		double **nSumOTC1, **nSumOTC2;
		double **nSumOTC;














		/// test class FCorrelatorMSD: 
		FILE *MSD;
		int MID; /// # of atoms input for MSD calculations, MID= middle or out  atoms
		FCorrelatorMSD msd1, msd2;
		flkVecR *molM1, *molM2;

		/// /// test class FCorrelatorACF: 
		FILE *ACF;
		FCorrelatorACF acf1, acf2;
		flkVecR *molA1, *molA2;










		/** Points per correlator */
		unsigned int p;
		/** Number of points over which to average; RECOMMENDED: p mod m = 0 */
		unsigned int m;
		/** Number of Correlators */
		unsigned int numcorrelators;







	private:
		int natoms, ntotal;
		int nevery_save;
		int unwrap_flag;            // 1 if atom coords are unwrapped, 0 if no
		float precision;            // user-adjustable precision setting
		float *coords;
		double sfactor, tfactor;     // scaling factors for positions and time unit


		void init_style();
		int modify_param(int, char **);
		void write_header(bigint);
		void pack(tagint *);
		void write_data(int, double *);
		bigint memory_usage();

		void write_frame();

		int me;

		int nfreq;
		int nevery;
		int nChain11, nChain22;
		int chainLen11, chainLen22;

	};

}

#endif
#endif

/* ERROR/WARNING messages:

E: Illegal ... command

Self-explanatory.  Check the input script syntax and compare to the
documentation for the command.  You can use -echo screen as a
command-line option when running LAMMPS to see the offending line.

E: Invalid dump xtc filename

Filenames used with the dump xtc style cannot be binary or compressed
or cause multiple files to be written.

E: Too many atoms for dump xtc

The system size must fit in a 32-bit integer to use this dump
style.

W: No automatic unit conversion to XTC file format conventions possible for units lj

This means no scaling will be performed.

E: Dump xtc requires sorting by atom ID

Use the dump_modify sort command to enable this.

E: Cannot set dump_modify flush for dump xtc

Self-explanatory.

E: Cannot use variable every setting for dump xtc

The format of this file requires snapshots at regular intervals.

E: Cannot change dump_modify every for dump xtc

The frequency of writing dump xtc snapshots cannot be changed.

E: Cannot open dump file

Self-explanatory.

E: Too big a timestep for dump xtc

The timestep must fit in a 32-bit integer to use this dump style.

E: Illegal dump_modify sfactor value (must be > 0.0)

Self-explanatory.

E: Illegal dump_modify tfactor value (must be > 0.0)

Self-explanatory.

*/
