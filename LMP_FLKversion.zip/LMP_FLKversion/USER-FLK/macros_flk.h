#ifndef MACROS_FLK_h
#define MACROS_FLK_h

/*****self definitions: start***********************/
typedef struct {
	double x, y, z;
}flkVecR;

typedef struct {
	flkVecR position;
	int id, type;
}flkMol;

#define flkVSet(v,sx,sy,sz)  \
	(v).x = sx, \
	(v).y = sy, \
	(v).z = sz

#define flkVSub(v1, v2, v3)   \
	(v1).x = (v2).x - (v3).x, \
	(v1).y = (v2).y - (v3).y, \
	(v1).z = (v2).z - (v3).z

#define flkVCopy(v1, v2)         \
	(v1).x = (v2).x, \
	(v1).y = (v2).y, \
	(v1).z = (v2).z

#define flkVDot(v1, v2)             \
	((v1).x * (v2).x + (v1).y * (v2).y + (v1).z * (v2).z)

#define flkVLen(v)  sqrt (flkVDot (v, v))

#define flkVLenSq(v)  flkVDot (v, v)

#define flkVAdd(v1, v2, v3)            \
	(v1).x = (v2).x + (v3).x, \
	(v1).y = (v2).y + (v3).y, \
	(v1).z = (v2).z + (v3).z

#define flkVVAdd(v1, v2)  flkVAdd (v1, v1, v2)

#define flkVScale(v, s)               \
	(v).x *= s, \
	(v).y *= s, \
	(v).z *= s
/*****self definitions: end***********************/



/*--------------------------------*
void itoa_Linux(int i, char*string)
{
	int power, j;
	j = i;
	for (power = 1; j >= 10; j /= 10)
		power *= 10;
	for (; power>0; power /= 10)
	{
		*string++ = '0' + i / power;
		i %= power;
	}
	*string = '\0';
}

/*--------------------------------*/




#endif // !MACROS_FLK_h

