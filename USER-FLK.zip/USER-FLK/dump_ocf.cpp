/* ----------------------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------
   Contributing authors: Naveen Michaud-Agrawal (Johns Hopkins U)
                         open-source XDR routines from
                           Frans van Hoesel (http://md.chem.rug.nl/hoesel)
                           are included in this file
                         Axel Kohlmeyer (Temple U)
                           port to platforms without XDR support
                           added support for unwrapped trajectories
                           support for groups
------------------------------------------------------------------------- */

#include <math.h>
#include <cmath>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "dump_ocf.h"
#include "domain.h"
#include "atom.h"
#include "update.h"
#include "group.h"
#include "output.h"
#include "force.h"
#include "comm.h"
#include "memory.h"
#include "error.h"
#include "force.h"

#include "modify.h"
#include "compute.h"
#include "input.h"


using namespace LAMMPS_NS;

// customize by adding keyword

#define EPS 1e-5
#define OCF_MAGIC 1995

#define MYMIN(a,b) ((a) < (b) ? (a) : (b))
#define MYMAX(a,b) ((a) > (b) ? (a) : (b))


/* ---------------------------------------------------------------------- */

DumpOCF::DumpOCF(LAMMPS *lmp, int narg, char **arg) : Dump(lmp, narg, arg),
  coords(NULL)
{
  if (narg < 5) error->all(FLERR,"Illegal dump OCF command");
  //if (binary || compressed || multifile || multiproc)
  //  error->all(FLERR,"Invalid dump OCF filename");

  size_one = 3;
  sort_flag = 1;
  sortcol = 0;
  format_default = NULL;
  flush_flag = 0;
  unwrap_flag = 1;
  precision = 1000000.0;

  MPI_Comm_rank(world, &me);

  OCF = NULL;
  OCFALL = NULL;
  nOCF = NULL;
  nOCFALL = NULL;

  MSD = NULL;
  ACF = NULL;



  // allocate global array for atom coords

  bigint n = group->count(igroup);
  if (n > static_cast<bigint>(MAXSMALLINT/3/sizeof(float)))
    error->all(FLERR,"Too many atoms for dump OCF");
  natoms = static_cast<int> (n);

  memory->create(coords,3*natoms,"dump:coords");

  xatoms = new flkVecR[natoms];

  p = 16;
  m = 2;
  numcorrelators = 32;

  nChain11 = 0;
  chainLen11 = 0;
  nChain22 = 0;
  chainLen22 = 0;



  nevery = 1;
  nfreq = 100;

  nevery = force->inumeric(FLERR, arg[3]);
  nfreq = force->inumeric(FLERR, arg[4]);
  if (me == 0)
  {
	  if (screen) fprintf(screen, "reading iarg: %d\tnfreq:%d\n", 3, nevery);
	  if (logfile) fprintf(logfile, "reading iarg: %d\tnfreq:%d\n", 3, nevery);
	  if (screen) fprintf(screen, "reading iarg: %d\tnevery:%d\n", 4, nfreq);
	  if (logfile) fprintf(logfile, "reading iarg: %d\tnevery:%d\n", 4, nfreq);
  }




  /***********/
  int iarg = 5;
  while (iarg < narg) {
	  if (strcmp(arg[iarg], "MID") == 0) {
		  if (iarg + 2 > narg)
			  error->all(FLERR, "Illegal ocfdump command: MID");
		  MID = force->inumeric(FLERR, arg[iarg + 1]);
		  if (me == 0)
		  {
			  if (screen) fprintf(screen, "reading iarg: %d\tMID:%d\n", iarg, MID);
			  if (logfile) fprintf(logfile, "reading iarg: %d\tMID:%d\n", iarg, MID);
		  }
		  iarg += 2;
	  }
	  else if (strcmp(arg[iarg], "nChain11") == 0) {
		  if (iarg + 2 > narg)
			  error->all(FLERR, "Illegal ocfdump command: nChain11");
		  nChain11 = force->inumeric(FLERR, arg[iarg + 1]);
		  if (me == 0)
		  {
			  if (screen) fprintf(screen, "reading iarg: %d\tnChain11:%d\n", iarg, nChain11);
			  if (logfile) fprintf(logfile, "reading iarg: %d\tnChain11:%d\n", iarg, nChain11);
		  }
		  iarg += 2;
	  }
	  else if (strcmp(arg[iarg], "nChain22") == 0) {
		  if (iarg + 2 > narg)
			  error->all(FLERR, "Illegal ocfdump command: nChain22");
		  nChain22 = force->inumeric(FLERR, arg[iarg + 1]);
		  if (me == 0)
		  {
			  if (screen) fprintf(screen, "reading iarg: %d\tnChain22:%d\n", iarg, nChain22);
			  if (logfile) fprintf(logfile, "reading iarg: %d\tnChain22:%d\n", iarg, nChain22);
		  }
		  iarg += 2;
	  }
	  else if (strcmp(arg[iarg], "chainLen11") == 0) {
		  if (iarg + 2 > narg)
			  error->all(FLERR, "Illegal ocfdump command: chainLen11");
		  chainLen11 = force->inumeric(FLERR, arg[iarg + 1]);
		  if (me == 0)
		  {
			  if (screen) fprintf(screen, "reading iarg: %d\tchainLen11:%d\n", iarg, chainLen11);
			  if (logfile) fprintf(logfile, "reading iarg: %d\tnchainLen11:%d\n", iarg, chainLen11);
		  }
		  iarg += 2;
	  }
	  else if (strcmp(arg[iarg], "chainLen22") == 0) {
		  if (iarg + 2 > narg)
			  error->all(FLERR, "Illegal ocfdump command: chainLen22");
		  chainLen22 = force->inumeric(FLERR, arg[iarg + 1]);
		  if (me == 0)
		  {
			  if (screen) fprintf(screen, "reading iarg: %d\tchainLen22:%d\n", iarg, chainLen22);
			  if (logfile) fprintf(logfile, "reading iarg: %d\tnchainLen22:%d\n", iarg, chainLen22);
		  }
		  iarg += 2;
	  }
	  else if (strcmp(arg[iarg], "ncorr") == 0) {
		  if (iarg + 2 > narg)
			  error->all(FLERR, "Illegal ocfdump command: ncorr");
		  numcorrelators = force->inumeric(FLERR, arg[iarg + 1]);
		  if (me == 0)
		  {
			  if (screen) fprintf(screen, "reading iarg: %d\tnumcorrelators:%d\n", iarg, numcorrelators);
			  if (logfile) fprintf(logfile, "reading iarg: %d\tnumcorrelators:%d\n", iarg, numcorrelators);
		  }
		  iarg += 2;
	  }
	  else if (strcmp(arg[iarg], "nlen") == 0) {
		  if (iarg + 2 > narg)
			  error->all(FLERR, "Illegal ocfdump command: nlen");
		  p = force->inumeric(FLERR, arg[iarg + 1]);
		  if (me == 0)
		  {
			  if (screen) fprintf(screen, "reading iarg: %d\tp:%d\n", iarg, p);
			  if (logfile) fprintf(logfile, "reading iarg: %d\tp:%d\n", iarg, p);
		  }
		  iarg += 2;
	  }
	  else if (strcmp(arg[iarg], "ncount") == 0) {
		  if (iarg + 2 > narg)
			  error->all(FLERR, "Illegal ocfdump command: ncount");
		  m = force->inumeric(FLERR, arg[iarg + 1]);
		  if (me == 0)
		  {
			  if (screen) fprintf(screen, "reading iarg: %d\tm:%d\n", iarg, m);
			  if (logfile) fprintf(logfile, "reading iarg: %d\tm:%d\n", iarg, m);
		  }
		  iarg += 2;
	  }
	  /********************************************************************************
	  else if (strcmp(arg[iarg], "file") == 0) {
		  if (iarg + 2 > narg)
			  error->all(FLERR, "Illegal ocfdump command: ocffile");
		  if (me == 0) {
			  if (screen) fprintf(screen, "reading iarg: %d\tfile:%s\n", iarg, arg[iarg + 1]);
			  if (logfile) fprintf(logfile, "reading iarg: %d\tfile:%s\n", iarg, arg[iarg + 1]);
			  ocf = fopen(arg[iarg + 1], "w");
			  if (ocf == NULL) {
				  char str[128];
				  sprintf(str, "Cannot open ocfdump result file %s", arg[iarg + 1]);
				  error->one(FLERR, str);
			  }
		  }
		  iarg += 2;
	  }
	  /********************************************************************************/
	  else error->all(FLERR, "Illegal ocfdump command: others");

  }
  /***********/




  if ((nChain11 * chainLen11 + nChain22 * chainLen22) != natoms)
	  error->all(FLERR, "FCorrelator: total atoms: error parameters for nChain and chainLen");


  if (p % m != 0) error->all(FLERR, "Fcorrelator: p mod m must be 0");


  if (nevery <= 0 || nfreq <= 0)
	  error->all(FLERR, "Illegal fix ave/correlator/msd command: nfreq  nevery 0");
  if (nfreq % nevery)
	  error->all(FLERR, "Illegal fix ave/correlator/msd command: nfreq  nevery");

  // allocate and initialize memory for calculated values and correlators



  // sfactor = conversion of coords to XTC units
  // tfactor = conversion of simulation time to XTC units
  // GROMACS standard is nanometers and picoseconds

  sfactor = 0.1 / force->angstrom;
  tfactor = 0.001 / force->femtosecond;

  // in reduced units we do not scale anything
  if (strcmp(update->unit_style,"lj") == 0) {
    sfactor = tfactor = 1.0;
    if (comm->me == 0)
      error->warning(FLERR,"No automatic unit conversion to XTC file "
                     "format conventions possible for units lj");
  }


  nevery_save = 0;
  ntotal = 0;


  /// test class FCorrelator:  
  //if (ocf&&me == 0)
  
  if ((me == 0) && (OCF == NULL)&& (OCFALL == NULL))
  {
	  OCF = fopen("ResultsOCF", "w");
	  if (OCF)
		  fprintf(OCF, "t\tSt\tS1\tS2\tA1\tA2\tC1\tC2\tC12\tKappa\n");

	  OCFALL = fopen("ResultsOCFall", "w");
	  if (OCFALL)
		  fprintf(OCFALL, "t\tSxy\tSxz\tSyz\tSxy1\tSxz1\tSyz1\tSxy2\tSxz2\tSyz2\tAxy1\tAxz1\tAyz1\tAxy2\tAxz2\tAyz2\tCxy1\tCxz1\tCyz1\tCxy2\tCxz2\tCyz2\tCxy12\tCxz12\tCyz12\tKappa\n");
  }
  if ((me == 0) && (nOCF == NULL) && (nOCFALL == NULL))
  {
	  nOCF = fopen("ResultsnOCF", "w");
	  fprintf(nOCF, "t\tSt\tS1\tS2\tA1\tA2\tC1\tC2\tC12\tKappa\n");

	  nOCFALL = fopen("ResultsnOCFall", "w");
	  fprintf(nOCFALL, "t\tSxy\tSxz\tSyz\tSxy1\tSxz1\tSyz1\tSxy2\tSxz2\tSyz2\tAxy1\tAxz1\tAyz1\tAxy2\tAxz2\tAyz2\tCxy1\tCxz1\tCyz1\tCxy2\tCxz2\tCyz2\tCxy12\tCxz12\tCyz12\tKappa\n");
  }
 





  nBond1 = (((double)chainLen11 - 1.0)*((double)nChain11));
  nBond2 = (((double)chainLen22 - 1.0)*((double)nChain22));
  nBond = nBond1 + nBond2;
  phi1 = (((double)nChain11)*((double)chainLen11)) / ((double)natoms);
  phi2 = (((double)nChain22)*((double)chainLen22)) / ((double)natoms);
  Sxy.setsize(numcorrelators, p, m, 1); /// only 1 input argument per frame
  Sxy.initialize();
  Sxz.setsize(numcorrelators, p, m, 1);
  Sxz.initialize();
  Syz.setsize(numcorrelators, p, m, 1);
  Syz.initialize();
  Sxy1.setsize(numcorrelators, p, m, 1); /// only 1 input argument per frame
  Sxy1.initialize();
  Sxz1.setsize(numcorrelators, p, m, 1);
  Sxz1.initialize();
  Syz1.setsize(numcorrelators, p, m, 1);
  Syz1.initialize();
  Sxy2.setsize(numcorrelators, p, m, 1); /// only 1 input argument per frame
  Sxy2.initialize();
  Sxz2.setsize(numcorrelators, p, m, 1);
  Sxz2.initialize();
  Syz2.setsize(numcorrelators, p, m, 1);
  Syz2.initialize();
  Axy1.setsize(numcorrelators, p, m, nChain11); /// # of chains = input argument per frame
  Axy1.initialize();
  Axz1.setsize(numcorrelators, p, m, nChain11);
  Axz1.initialize();
  Ayz1.setsize(numcorrelators, p, m, nChain11);
  Ayz1.initialize();
  Axy2.setsize(numcorrelators, p, m, nChain22); /// # of chains = input argument per frame
  Axy2.initialize();
  Axz2.setsize(numcorrelators, p, m, nChain22);
  Axz2.initialize();
  Ayz2.setsize(numcorrelators, p, m, nChain22);
  Ayz2.initialize();


  /// Orientation Tensor of Chain1 and Chain2: 6 -> xx, yy, zz, xy, xz, yz
  OTC1 = new double*[6];
  OTC2 = new double*[6];
  OTC12 = new double*[6];
  for (int i = 0; i < 6; i++) {
	  OTC1[i] = new double[nChain11];
	  for (int j = 0; j < nChain11; j++) {
		  OTC1[i][j] = 0.0;
	  }
	  OTC2[i] = new double[nChain22];
	  for (int j = 0; j < nChain22; j++) {
		  OTC2[i][j] = 0.0;
	  }
	  OTC12[i] = new double[nChain11 + nChain22];
	  for (int j = 0; j < (nChain11 + nChain22); j++) {
		  OTC12[i][j] = 0.0;
	  }
  }

  SumOTC1 = new double*[6];
  SumOTC2 = new double*[6];
  SumOTC = new double*[6];
  for (int i = 0; i < 6; i++) {
	  SumOTC1[i] = new double[1];
	  SumOTC2[i] = new double[1];
	  SumOTC[i] = new double[1];
	  SumOTC1[i][0] = 0.0;
	  SumOTC2[i][0] = 0.0;
	  SumOTC[i][0] = 0.0;
  }


  {
	  nSxy.setsize(numcorrelators, p, m, 1); /// only 1 input argument per frame
	  nSxy.initialize();
	  nSxz.setsize(numcorrelators, p, m, 1);
	  nSxz.initialize();
	  nSyz.setsize(numcorrelators, p, m, 1);
	  nSyz.initialize();
	  nSxy1.setsize(numcorrelators, p, m, 1); /// only 1 input argument per frame
	  nSxy1.initialize();
	  nSxz1.setsize(numcorrelators, p, m, 1);
	  nSxz1.initialize();
	  nSyz1.setsize(numcorrelators, p, m, 1);
	  nSyz1.initialize();
	  nSxy2.setsize(numcorrelators, p, m, 1); /// only 1 input argument per frame
	  nSxy2.initialize();
	  nSxz2.setsize(numcorrelators, p, m, 1);
	  nSxz2.initialize();
	  nSyz2.setsize(numcorrelators, p, m, 1);
	  nSyz2.initialize();
	  nAxy1.setsize(numcorrelators, p, m, nChain11); /// # of chains = input argument per frame
	  nAxy1.initialize();
	  nAxz1.setsize(numcorrelators, p, m, nChain11);
	  nAxz1.initialize();
	  nAyz1.setsize(numcorrelators, p, m, nChain11);
	  nAyz1.initialize();
	  nAxy2.setsize(numcorrelators, p, m, nChain22); /// # of chains = input argument per frame
	  nAxy2.initialize();
	  nAxz2.setsize(numcorrelators, p, m, nChain22);
	  nAxz2.initialize();
	  nAyz2.setsize(numcorrelators, p, m, nChain22);
	  nAyz2.initialize();

	  nOTC1 = new double*[6];
	  nOTC2 = new double*[6];
	  nOTC12 = new double*[6];
	  for (int i = 0; i < 6; i++) {
		  nOTC1[i] = new double[nChain11];
		  for (int j = 0; j < nChain11; j++) {
			  nOTC1[i][j] = 0.0;
		  }
		  nOTC2[i] = new double[nChain22];
		  for (int j = 0; j < nChain22; j++) {
			  nOTC2[i][j] = 0.0;
		  }
		  nOTC12[i] = new double[nChain11 + nChain22];
		  for (int j = 0; j < (nChain11 + nChain22); j++) {
			  nOTC12[i][j] = 0.0;
		  }
	  }

	  nSumOTC1 = new double*[6];
	  nSumOTC2 = new double*[6];
	  nSumOTC = new double*[6];
	  for (int i = 0; i < 6; i++) {
		  nSumOTC1[i] = new double[1];
		  nSumOTC2[i] = new double[1];
		  nSumOTC[i] = new double[1];
		  nSumOTC1[i][0] = 0.0;
		  nSumOTC2[i][0] = 0.0;
		  nSumOTC[i][0] = 0.0;
	  }
  }



  /// test class FCorrelatorMSD: 
  if ((me == 0) && (MSD == NULL))
  {
	  MSD = fopen("ResultsMSD", "w");
	  if (MSD)
		  fprintf(MSD, "t\tg1a_1\tg1a_2\n");
  }

  msd1.setsize(numcorrelators, p, m, (nChain11*MID));
  msd1.initialize();
  molM1 = new flkVecR[nChain11*MID];

  msd2.setsize(numcorrelators, p, m, (nChain22*MID));
  msd2.initialize();
  molM2 = new flkVecR[nChain22*MID];

  /// test class FCorrelatosACF: 
  if ((me == 0) && (ACF == NULL))
  {
	  ACF = fopen("ResultsACF", "w");
	  if (ACF)
		  fprintf(ACF, "t\tACF1\tACF2\n");
  }

  acf1.setsize(numcorrelators, p, m, nChain11);
  acf1.initialize();
  molA1 = new flkVecR[nChain11];

  acf2.setsize(numcorrelators, p, m, nChain22);
  acf2.initialize();
  molA2 = new flkVecR[nChain22];



}

/* ---------------------------------------------------------------------- */

DumpOCF::~DumpOCF()
{
  memory->destroy(coords);


  if (OCF&&me == 0) fclose(OCF); ///FLK
  if (OCFALL&&me == 0) fclose(OCFALL);
  if (nOCF&&me == 0) fclose(nOCF); ///FLK
  if (nOCFALL&&me == 0) fclose(nOCFALL);

  if (MSD&&me == 0) fclose(MSD);
  if (ACF&&me == 0)  fclose(ACF);


}

/* ---------------------------------------------------------------------- */


/* ---------------------------------------------------------------------- */
void DumpOCF::init_style()
{
  if (sort_flag == 0 || sortcol != 0)
    error->all(FLERR,"Dump OCF requires sorting by atom ID");

  // check that flush_flag is not set since dump::write() will use it

  if (flush_flag) error->all(FLERR,"Cannot set dump_modify flush for dump xtc");

  // check that dump frequency has not changed and is not a variable

  int idump;
  for (idump = 0; idump < output->ndump; idump++)
    if (strcmp(id,output->dump[idump]->id) == 0) break;
  if (output->every_dump[idump] == 0)
    error->all(FLERR,"Cannot use variable every setting for dump xtc");

  if (nevery_save == 0) nevery_save = output->every_dump[idump];
  else if (nevery_save != output->every_dump[idump])
    error->all(FLERR,"Cannot change dump_modify every for dump xtc");
}
/* ---------------------------------------------------------------------- */


void DumpOCF::write_header(bigint nbig)
{
  if (nbig > MAXSMALLINT) error->all(FLERR,"Too many atoms for dump xtc");
  int n = nbig;
  if (update->ntimestep > MAXSMALLINT)
    error->one(FLERR,"Too big a timestep for dump xtc");
  int ntimestep = update->ntimestep;

  // all procs realloc coords if total count grew

  if (n != natoms) {
    natoms = n;
    memory->destroy(coords);
    memory->create(coords,3*natoms,"dump:coords");
  }

  // only proc 0 writes header

  if (me != 0) return;

  int tmp = OCF_MAGIC;


  // cell basis vectors
  if (domain->triclinic) {
    float zero = 0.0;
    float xdim = sfactor * (domain->boxhi[0] - domain->boxlo[0]);
    float ydim = sfactor * (domain->boxhi[1] - domain->boxlo[1]);
    float zdim = sfactor * (domain->boxhi[2] - domain->boxlo[2]);
    float xy = sfactor * domain->xy;
    float xz = sfactor * domain->xz;
    float yz = sfactor * domain->yz;


  } else {
    float zero = 0.0;
    float xdim = sfactor * (domain->boxhi[0] - domain->boxlo[0]);
    float ydim = sfactor * (domain->boxhi[1] - domain->boxlo[1]);
    float zdim = sfactor * (domain->boxhi[2] - domain->boxlo[2]);

  }
}

/* ---------------------------------------------------------------------- */

void DumpOCF::pack(tagint *ids)
{
  int m,n;

  tagint *tag = atom->tag;
  double **x = atom->x;
  imageint *image = atom->image;
  int *mask = atom->mask;
  int nlocal = atom->nlocal;

  m = n = 0;
  if (unwrap_flag == 1) {
    double xprd = domain->xprd;
    double yprd = domain->yprd;
    double zprd = domain->zprd;
    double xy = domain->xy;
    double xz = domain->xz;
    double yz = domain->yz;

    for (int i = 0; i < nlocal; i++)
      if (mask[i] & groupbit) {
        int ix = (image[i] & IMGMASK) - IMGMAX;
        int iy = (image[i] >> IMGBITS & IMGMASK) - IMGMAX;
        int iz = (image[i] >> IMG2BITS) - IMGMAX;

        if (domain->triclinic) {
          buf[m++] = sfactor * (x[i][0] + ix * xprd + iy * xy + iz * xz);
          buf[m++] = sfactor * (x[i][1] + iy * yprd + iz * yz);
          buf[m++] = sfactor * (x[i][2] + iz * zprd);
        } else {
          buf[m++] = sfactor * (x[i][0] + ix * xprd);
          buf[m++] = sfactor * (x[i][1] + iy * yprd);
          buf[m++] = sfactor * (x[i][2] + iz * zprd);
        }
        ids[n++] = tag[i];
      }

  } else {
    for (int i = 0; i < nlocal; i++)
      if (mask[i] & groupbit) {
        buf[m++] = sfactor*x[i][0];
        buf[m++] = sfactor*x[i][1];
        buf[m++] = sfactor*x[i][2];
        ids[n++] = tag[i];
      }
  }
}

/* ---------------------------------------------------------------------- */

void DumpOCF::write_data(int n, double *mybuf)
{
  // copy buf atom coords into global array

  int m = 0;
  int k = 3*ntotal;
  for (int i = 0; i < n; i++) {
    coords[k++] = mybuf[m++];
    coords[k++] = mybuf[m++];
    coords[k++] = mybuf[m++];
    ntotal++;
  }

  // if last chunk of atoms in this snapshot, write global arrays to file

  if (ntotal == natoms) {
    write_frame();
    ntotal = 0;
  }
}

/* ---------------------------------------------------------------------- */

int DumpOCF::modify_param(int narg, char **arg)
{
  if (strcmp(arg[0],"unwrap") == 0) {
    if (narg < 2) error->all(FLERR,"Illegal dump_modify command");
    if (strcmp(arg[1],"yes") == 0) unwrap_flag = 1;
    else if (strcmp(arg[1],"no") == 0) unwrap_flag = 0;
    else error->all(FLERR,"Illegal dump_modify command");
    return 2;
  } else if (strcmp(arg[0],"precision") == 0) {
    if (narg < 2) error->all(FLERR,"Illegal dump_modify command");
    precision = force->numeric(FLERR,arg[1]);
    if ((fabs(precision-10.0) > EPS) && (fabs(precision-100.0) > EPS) &&
        (fabs(precision-1000.0) > EPS) && (fabs(precision-10000.0) > EPS) &&
        (fabs(precision-100000.0) > EPS) &&
        (fabs(precision-1000000.0) > EPS))
      error->all(FLERR,"Illegal dump_modify command");
    return 2;
  } else if (strcmp(arg[0],"sfactor") == 0) {
    if (narg < 2) error->all(FLERR,"Illegal dump_modify command");
    sfactor = force->numeric(FLERR,arg[1]);
    if (sfactor <= 0.0)
      error->all(FLERR,"Illegal dump_modify sfactor value (must be > 0.0)");
    return 2;
  } else if (strcmp(arg[0],"tfactor") == 0) {
    if (narg < 2) error->all(FLERR,"Illegal dump_modify command");
    tfactor = force->numeric(FLERR,arg[1]);
    if (tfactor <= 0.0)
      error->all(FLERR,"Illegal dump_modify tfactor value (must be > 0.0)");
    return 2;
  }
  return 0;
}

/* ----------------------------------------------------------------------
   return # of bytes of allocated memory in buf and global coords array
------------------------------------------------------------------------- */

bigint DumpOCF::memory_usage()
{

  bigint bytes = Dump::memory_usage();
  bytes += memory->usage(coords,natoms*3);



  return bytes;
}

/* ---------------------------------------------------------------------- */

void DumpOCF::write_frame()
{


  //if (OCF&&me == 0)
	if (me == 0)
	  {
		  for (int i = 0; i < natoms; i++)
		  {
			  flkVSet(xatoms[i], coords[i * 3], coords[i * 3 + 1], coords[i * 3 + 2]);
			 
			  //fprintf(ocf, "%d\t%lg\t%lg\t%lg\n", i + 1, flkmol[i].position.x, flkmol[i].position.y, flkmol[i].position.z);
			  //fprintf(ocf, "%d\t%lg\t%lg\t%lg\n", i + 1, coords[i * 3], coords[i * 3 + 1], coords[i * 3 + 2]);
		 }
	 }

  /// test class FCorrelator: 
	/*-Orientation Tensor------------------------------------------------------*/
	for (int j = 0; j < 6; j++) {
		for (int k = 0; k < nChain11; k++) {
			OTC1[j][k] = 0.0;
			nOTC1[j][k] = 0.0;
		}
	}
	//Bondlength = 0.0;
	for (int j = 0; j < nChain11; j++) {
		for (int k = 0; k < chainLen11 - 1; k++) {
			i1 = k + j * chainLen11;
			i2 = i1 + 1;
			flkVSet(BondVector, xatoms[i1].x - xatoms[i2].x, xatoms[i1].y - xatoms[i2].y, xatoms[i1].z - xatoms[i2].z); /// Without Normalization by the bond length
			OTC1[0][j] += BondVector.x*BondVector.x;
			OTC1[1][j] += BondVector.y*BondVector.y;
			OTC1[2][j] += BondVector.z*BondVector.z;
			OTC1[3][j] += BondVector.x*BondVector.y;
			OTC1[4][j] += BondVector.x*BondVector.z;
			OTC1[5][j] += BondVector.y*BondVector.z;


			/// normalized: 
			Bondlength= flkVLen(BondVector);
			BondVector.x /= Bondlength;
			BondVector.y /= Bondlength;
			BondVector.z /= Bondlength;
			nOTC1[0][j] += BondVector.x*BondVector.x;
			nOTC1[1][j] += BondVector.y*BondVector.y;
			nOTC1[2][j] += BondVector.z*BondVector.z;
			nOTC1[3][j] += BondVector.x*BondVector.y;
			nOTC1[4][j] += BondVector.x*BondVector.z;
			nOTC1[5][j] += BondVector.y*BondVector.z;





			//Bondlength += flkVLen(BondVector);
		}
	}
	///bonglength1 << length / nBond1 << std::endl; ///output bonglength1


	for (int j = 0; j < 6; j++) {
		for (int k = 0; k < nChain22; k++) {
			OTC2[j][k] = 0.0;
			nOTC2[j][k] = 0.0;

		}
	}
	//Bondlength = 0.0;
	for (int j = 0; j < nChain22; j++) {
		for (int k = 0; k < chainLen22 - 1; k++) {
			i1 = k + j * chainLen22 + nChain11 * chainLen11;
			i2 = i1 + 1;
			flkVSet(BondVector, xatoms[i1].x - xatoms[i2].x, xatoms[i1].y - xatoms[i2].y, xatoms[i1].z - xatoms[i2].z);
			OTC2[0][j] += BondVector.x*BondVector.x;
			OTC2[1][j] += BondVector.y*BondVector.y;
			OTC2[2][j] += BondVector.z*BondVector.z;
			OTC2[3][j] += BondVector.x*BondVector.y;
			OTC2[4][j] += BondVector.x*BondVector.z;
			OTC2[5][j] += BondVector.y*BondVector.z;


			/// normalized: 
			Bondlength = flkVLen(BondVector);
			BondVector.x /= Bondlength;
			BondVector.y /= Bondlength;
			BondVector.z /= Bondlength;
			nOTC2[0][j] += BondVector.x*BondVector.x;
			nOTC2[1][j] += BondVector.y*BondVector.y;
			nOTC2[2][j] += BondVector.z*BondVector.z;
			nOTC2[3][j] += BondVector.x*BondVector.y;
			nOTC2[4][j] += BondVector.x*BondVector.z;
			nOTC2[5][j] += BondVector.y*BondVector.z;



			//Bondlength += flkVLen(BondVector);
		}
	}


	for (int k = 0; k < 6; k++) {
		for (int j = 0; j < nChain11; j++) {
			OTC12[k][j] = OTC1[k][j];


			nOTC12[k][j] = nOTC1[k][j];
		}
		for (int j = nChain11; j < (nChain11 + nChain22); j++) {
			OTC12[k][j] = OTC2[k][j - nChain11];


			nOTC12[k][j] = nOTC2[k][j - nChain11];
		}
	}

	Axy1.add(OTC1[3]);
	Axz1.add(OTC1[4]);
	Ayz1.add(OTC1[5]);
	Axy2.add(OTC2[3]);
	Axz2.add(OTC2[4]);
	Ayz2.add(OTC2[5]);


	nAxy1.add(nOTC1[3]);
	nAxz1.add(nOTC1[4]);
	nAyz1.add(nOTC1[5]);
	nAxy2.add(nOTC2[3]);
	nAxz2.add(nOTC2[4]);
	nAyz2.add(nOTC2[5]);





	for (int j = 0; j < 6; j++) {
		SumOTC1[j][0] = 0.0;
		SumOTC2[j][0] = 0.0;
		SumOTC[j][0] = 0.0;


		nSumOTC1[j][0] = 0.0;
		nSumOTC2[j][0] = 0.0;
		nSumOTC[j][0] = 0.0;
	}

	for (int j = 0; j < 6; j++) {
		for (int k = 0; k < nChain11; k++) {
			SumOTC1[j][0] += OTC1[j][k];
			SumOTC[j][0] += OTC1[j][k];


			nSumOTC1[j][0] += nOTC1[j][k];
			nSumOTC[j][0] += nOTC1[j][k];
		}
		for (int k = 0; k < nChain22; k++) {
			SumOTC2[j][0] += OTC2[j][k];
			SumOTC[j][0] += OTC2[j][k];


			nSumOTC2[j][0] += nOTC2[j][k];
			nSumOTC[j][0] += nOTC2[j][k];
		}
	}

	/*-Orientation Tensor------------------------------------------------------*/

	Sxy.add(SumOTC[3]);
	Sxz.add(SumOTC[4]);
	Syz.add(SumOTC[5]);

	Sxy1.add(SumOTC1[3]);
	Sxz1.add(SumOTC1[4]);
	Syz1.add(SumOTC1[5]);

	Sxy2.add(SumOTC2[3]);
	Sxz2.add(SumOTC2[4]);
	Syz2.add(SumOTC2[5]);


	nSxy.add(nSumOTC[3]);
	nSxz.add(nSumOTC[4]);
	nSyz.add(nSumOTC[5]);

	nSxy1.add(nSumOTC1[3]);
	nSxz1.add(nSumOTC1[4]);
	nSyz1.add(nSumOTC1[5]);

	nSxy2.add(nSumOTC2[3]);
	nSxz2.add(nSumOTC2[4]);
	nSyz2.add(nSumOTC2[5]);





	Sxy.evaluate();
	Sxz.evaluate();
	Syz.evaluate();
	Sxy1.evaluate();
	Sxz1.evaluate();
	Syz1.evaluate();
	Sxy2.evaluate();
	Sxz2.evaluate();
	Syz2.evaluate();

	Axy1.evaluate();
	Axz1.evaluate();
	Ayz1.evaluate();
	Axy2.evaluate();
	Axz2.evaluate();
	Ayz2.evaluate();
  



	nSxy.evaluate();
	nSxz.evaluate();
	nSyz.evaluate();
	nSxy1.evaluate();
	nSxz1.evaluate();
	nSyz1.evaluate();
	nSxy2.evaluate();
	nSxz2.evaluate();
	nSyz2.evaluate();

	nAxy1.evaluate();
	nAxz1.evaluate();
	nAyz1.evaluate();
	nAxy2.evaluate();
	nAxz2.evaluate();
	nAyz2.evaluate();









	/// test MSD: 
	countMol = 0;
	for (int j = 0; j < nChain11; j++) {
		for (int k = 0; k < chainLen11; k++) { /// could be optimized...
			if (k >= ((chainLen11 - MID) / 2) && (k < ((chainLen11 - MID) / 2 + MID))) {
				indexAtom = k + j * chainLen11;
				flkVCopy(molM1[countMol], xatoms[indexAtom]);
				++countMol;
			}
		}
	}
	msd1.add(molM1);

	countMol = 0;
	for (int j = 0; j < nChain22; j++) {
		for (int k = 0; k < chainLen22; k++) { /// could be optimized...
			if (k >= ((chainLen22 - MID) / 2) && (k < ((chainLen22 - MID) / 2 + MID))) {
				indexAtom = k + j * chainLen22 + nChain11 * chainLen11;
				flkVCopy(molM2[countMol], xatoms[indexAtom]);
				++countMol;
			}
		}
	}
	msd2.add(molM2);


	msd1.evaluate();
	msd2.evaluate();


	///test ACF: 
	countMol = 0;
	for (int j = 0; j < nChain11; j++) {
		indexAtom = j * chainLen11;
		flkVSet(molA1[countMol], \
			xatoms[indexAtom].x - xatoms[indexAtom + chainLen11 - 1].x, \
			xatoms[indexAtom].y - xatoms[indexAtom + chainLen11 - 1].y, \
			xatoms[indexAtom].z - xatoms[indexAtom + chainLen11 - 1].z);
		++countMol;
	}
	acf1.add(molA1);

	countMol = 0;
	for (int j = 0; j < nChain22; j++) {
		indexAtom = j * chainLen22 + nChain11 * chainLen22;
		flkVSet(molA2[countMol], \
			xatoms[indexAtom].x - xatoms[indexAtom + chainLen22 - 1].x, \
			xatoms[indexAtom].y - xatoms[indexAtom + chainLen22 - 1].y, \
			xatoms[indexAtom].z - xatoms[indexAtom + chainLen22 - 1].z);
		++countMol;
	}
	acf2.add(molA2);

	acf1.evaluate();
	acf2.evaluate();












	// output result to file
	 bigint ntimestep = update->ntimestep;
	 if (ntimestep % nfreq) return;

	 if (ntimestep > 0)
	 {
		 if (OCF&&me == 0)
		 {
			 for (unsigned int i = 0; i < Sxy.npcorr; ++i)
			 {
				 st = (Sxy.f[i] + Sxz.f[i] + Syz.f[i]) / nBond / 3.0;
				 s1 = (Sxy1.f[i] + Sxz1.f[i] + Syz1.f[i]) / nBond1 / 3.0;
				 s2 = (Sxy2.f[i] + Sxz2.f[i] + Syz2.f[i]) / nBond2 / 3.0;
				 a1 = (Axy1.f[i] + Axz1.f[i] + Ayz1.f[i]) / ((double)chainLen11 - 1.0) / 3.0;
				 a2 = (Axy2.f[i] + Axz2.f[i] + Ayz2.f[i]) / ((double)chainLen22 - 1.0) / 3.0;
				 c1 = (s1 - a1) / phi1;
				 c2 = (s2 - a2) / phi2;
				 c12 = (st - phi1 * s1 - phi2 * s2) / (2.0*phi1*phi2);
				 kappa = (st - phi1 * a1 - phi2 * a2) / st;

				 /// output: 
				 fprintf(OCF, "%lg\t", Sxy.t[i] * update->dt*((double)nevery));
				 fprintf(OCF, "%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\n", st, s1, s2, a1, a2, c1, c2, c12, kappa);
			 }
			 fflush(OCF);
		 }



		 if (nOCF&&me == 0)
		 {
			 for (unsigned int i = 0; i < nSxy.npcorr; i++)
			 {
				 st = (nSxy.f[i] + nSxz.f[i] + nSyz.f[i]) / nBond / 3.0;
				 s1 = (nSxy1.f[i] + nSxz1.f[i] + nSyz1.f[i]) / nBond1 / 3.0;
				 s2 = (nSxy2.f[i] + nSxz2.f[i] + nSyz2.f[i]) / nBond2 / 3.0;
				 a1 = (nAxy1.f[i] + nAxz1.f[i] + nAyz1.f[i]) / ((double)chainLen11 - 1.0) / 3.0;
				 a2 = (nAxy2.f[i] + nAxz2.f[i] + nAyz2.f[i]) / ((double)chainLen22 - 1.0) / 3.0;
				 c1 = (s1 - a1) / phi1;
				 c2 = (s2 - a2) / phi2;
				 c12 = (st - phi1 * s1 - phi2 * s2) / (2.0*phi1*phi2);
				 kappa = (st - phi1 * a1 - phi2 * a2) / st;
				 /// output: 
				 fprintf(nOCF, "%lg\t", nSxy.t[i] * update->dt*((double)nevery));
				 fprintf(nOCF, "%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\n", st, s1, s2, a1, a2, c1, c2, c12, kappa);

			 }
		 }


		 if (OCFALL&&me == 0)
		 {
			 for (unsigned int i = 0; i < Sxy.npcorr; i++) {
				 double stx = Sxy.f[i] / nBond;
				 double sty = Sxz.f[i] / nBond;
				 double stz = Syz.f[i] / nBond;
				 double s1x = Sxy1.f[i] / nBond1;
				 double s1y = Sxz1.f[i] / nBond1;
				 double s1z = Syz1.f[i] / nBond1;
				 double s2x = Sxy2.f[i] / nBond2;
				 double s2y = Sxz2.f[i] / nBond2;
				 double s2z = Syz2.f[i] / nBond2;
				 double a1x = Axy1.f[i] / ((double)chainLen11 - 1.0);
				 double a1y = Axz1.f[i] / ((double)chainLen11 - 1.0);
				 double a1z = Ayz1.f[i] / ((double)chainLen11 - 1.0);
				 double a2x = Axy2.f[i] / ((double)chainLen22 - 1.0);
				 double a2y = Axz2.f[i] / ((double)chainLen22 - 1.0);
				 double a2z = Ayz2.f[i] / ((double)chainLen22 - 1.0);
				 double c1x = (Sxy1.f[i] / nBond1 - Axy1.f[i] / ((double)chainLen11 - 1.0)) / phi1;
				 double c1y = (Sxz1.f[i] / nBond1 - Axz1.f[i] / ((double)chainLen11 - 1.0)) / phi1;
				 double c1z = (Syz1.f[i] / nBond1 - Ayz1.f[i] / ((double)chainLen11 - 1.0)) / phi1;
				 double c2x = (Sxy2.f[i] / nBond2 - Axy2.f[i] / ((double)chainLen22 - 1.0)) / phi2;
				 double c2y = (Sxz2.f[i] / nBond2 - Axz2.f[i] / ((double)chainLen22 - 1.0)) / phi2;
				 double c2z = (Syz2.f[i] / nBond2 - Ayz2.f[i] / ((double)chainLen22 - 1.0)) / phi2;
				 double c12x = (Sxy.f[i] / nBond - phi1 * Sxy1.f[i] / nBond1 - phi2 * Sxy2.f[i] / nBond2) / (2.0*phi1*phi2);
				 double c12y = (Sxz.f[i] / nBond - phi1 * Sxz1.f[i] / nBond1 - phi2 * Sxz2.f[i] / nBond2) / (2.0*phi1*phi2);
				 double c12z = (Syz.f[i] / nBond - phi1 * Syz1.f[i] / nBond1 - phi2 * Syz2.f[i] / nBond2) / (2.0*phi1*phi2);

				 fprintf(OCFALL, "%lg\t", Sxy.t[i] * update->dt*((double)nevery));
				 fprintf(OCFALL, "%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\n", \
					 stx, sty, stz, s1x, s1y, s1z, s2x, s2y, s2z, a1x, a1y, a1z, a2x, a2y, a2z, c1x, c1y, c1z, c2x, c2y, c2z, c12x, c12y, c12z);


			 }
			 fflush(OCFALL);
		 }

		 if (nOCFALL&&me == 0)
		 {
			 for (unsigned int i = 0; i < nSxy.npcorr; i++) {
				 double stx = nSxy.f[i] / nBond;
				 double sty = nSxz.f[i] / nBond;
				 double stz = nSyz.f[i] / nBond;
				 double s1x = nSxy1.f[i] / nBond1;
				 double s1y = nSxz1.f[i] / nBond1;
				 double s1z = nSyz1.f[i] / nBond1;
				 double s2x = nSxy2.f[i] / nBond2;
				 double s2y = nSxz2.f[i] / nBond2;
				 double s2z = nSyz2.f[i] / nBond2;
				 double a1x = nAxy1.f[i] / ((double)chainLen11 - 1.0);
				 double a1y = nAxz1.f[i] / ((double)chainLen11 - 1.0);
				 double a1z = nAyz1.f[i] / ((double)chainLen11 - 1.0);
				 double a2x = nAxy2.f[i] / ((double)chainLen22 - 1.0);
				 double a2y = nAxz2.f[i] / ((double)chainLen22 - 1.0);
				 double a2z = nAyz2.f[i] / ((double)chainLen22 - 1.0);
				 double c1x = (nSxy1.f[i] / nBond1 - nAxy1.f[i] / ((double)chainLen11 - 1.0)) / phi1;
				 double c1y = (nSxz1.f[i] / nBond1 - nAxz1.f[i] / ((double)chainLen11 - 1.0)) / phi1;
				 double c1z = (nSyz1.f[i] / nBond1 - nAyz1.f[i] / ((double)chainLen11 - 1.0)) / phi1;
				 double c2x = (nSxy2.f[i] / nBond2 - nAxy2.f[i] / ((double)chainLen22 - 1.0)) / phi2;
				 double c2y = (nSxz2.f[i] / nBond2 - nAxz2.f[i] / ((double)chainLen22 - 1.0)) / phi2;
				 double c2z = (nSyz2.f[i] / nBond2 - nAyz2.f[i] / ((double)chainLen22 - 1.0)) / phi2;
				 double c12x = (nSxy.f[i] / nBond - phi1 * nSxy1.f[i] / nBond1 - phi2 * nSxy2.f[i] / nBond2) / (2.0*phi1*phi2);
				 double c12y = (nSxz.f[i] / nBond - phi1 * nSxz1.f[i] / nBond1 - phi2 * nSxz2.f[i] / nBond2) / (2.0*phi1*phi2);
				 double c12z = (nSyz.f[i] / nBond - phi1 * nSyz1.f[i] / nBond1 - phi2 * nSyz2.f[i] / nBond2) / (2.0*phi1*phi2);

				 fprintf(nOCFALL, "%lg\t", nSxy.t[i] * update->dt*((double)nevery));
				 fprintf(nOCFALL, "%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\n", \
					 stx, sty, stz, s1x, s1y, s1z, s2x, s2y, s2z, a1x, a1y, a1z, a2x, a2y, a2z, c1x, c1y, c1z, c2x, c2y, c2z, c12x, c12y, c12z);


			 }
			 fflush(nOCFALL);
		 }












		 if (MSD&&me == 0)
		 {
			 for (unsigned int i = 0; i < msd1.npcorr; i++) {
				 fprintf(MSD, "%lg\t", msd1.t[i] * update->dt*((double)nevery));
				 fprintf(MSD, "%lg\t%lg\n", msd1.f[i], msd2.f[i]);
			 }
			 fflush(MSD);
		 }

		 if (ACF&&me == 0)
		 {
			 for (unsigned int i = 0; i < acf1.npcorr; i++) {
				 fprintf(ACF, "%lg\t", acf1.t[i] * update->dt*((double)nevery));
				 fprintf(ACF, "%lg\t%lg\t%lg\t%lg\n", acf1.f[i], acf1.f[i] / acf1.f[0], acf2.f[i], acf2.f[i] / acf2.f[0]);

			 }
			 fflush(ACF);
		 }




	 }
}



FCorrelator::FCorrelator(const unsigned int numcorrin, const unsigned int pin, const unsigned int min, unsigned int ninput)
{
	setsize(numcorrin, pin, min, ninput);
}

FCorrelator::~FCorrelator()
{
	if (numcorrelators == 0) return;

	delete[] shift;
	delete[] correlation;
	delete[] ncorrelation;
	delete[] accumulator;
	delete[] naccumulator;
	delete[] insertindex;

	delete[] t;
	delete[] f;
}

void FCorrelator::setsize(const unsigned int numcorrin, const unsigned int pin, const unsigned int min, unsigned int ninput) {
	numcorrelators = numcorrin;
	p = pin;
	m = min;
	dmin = p / m;

	ni = ninput;
	double *w = new double[ni];
	length = numcorrelators * p;

	shift = new double**[numcorrelators];
	correlation = new double*[numcorrelators];
	ncorrelation = new unsigned long int *[numcorrelators];
	accumulator = new double*[numcorrelators];
	naccumulator = new unsigned int[numcorrelators];
	insertindex = new unsigned int[numcorrelators];

	accval = new double[ni];

	for (unsigned int j = 0; j < numcorrelators; ++j) {
		shift[j] = new double*[p];
		for (unsigned int i = 0; i < p; ++i) {
			shift[j][i] = new double[ni];
		}

		accumulator[j] = new double[ni];
		/* It can be optimized: Apart from correlator 0, correlation and ncorrelation arrays only use p/2 values */
		correlation[j] = new double[p];
		ncorrelation[j] = new unsigned long int[p];
	}

	t = new double[length];
	f = new double[length];
}

void FCorrelator::initialize() {
	for (unsigned int j = 0; j < numcorrelators; ++j) {
		for (unsigned int i = 0; i < p; ++i) {
			for (unsigned int k = 0; k < ni; ++k) {
				//VSet(shift[j][i][k], -2E10, -2E10, -2E10);
				shift[j][i][k] = -2E10;
			}
			correlation[j][i] = 0.0;
			ncorrelation[j][i] = 0;
		}
		for (unsigned int a = 0; a < ni; ++a) {
			//VSet(accumulator[j][a], 0.0, 0.0, 0.0);
			accumulator[j][a] = 0.0;
		}

		naccumulator[j] = 0;
		insertindex[j] = 0;
	}

	for (unsigned int i = 0; i < length; ++i) {
		t[i] = 0.0;
		f[i] = 0.0;
	}

	npcorr = 0;
	kmax = 0;
	for (unsigned int i = 0; i < ni; ++i) {
		//VSet(accval[i], 0.0, 0.0, 0.0);
		accval[i] = 0.0;
	}
}

void FCorrelator::add(double *w, const unsigned int k) {
	/// If we exceed the correlator side, the value is discarded
	if (k == numcorrelators) return;
	if (k > kmax) kmax = k;

	/// Insert new value in shift array
	for (unsigned int i = 0; i < ni; ++i) {
		//VCopy(shift[k][insertindex[k]][i], w[i]);	
		shift[k][insertindex[k]][i] = w[i];
	}

	/// Add to aveage value
	if (k == 0) {
		for (unsigned int a = 0; a < ni; ++a) {
			//VVAdd(accval[a], w[a]);
			accval[a] += w[a];
		}
	}


	/// Add to accumulator and, if needed, add to next correlator
	/****************************************/
	for (unsigned int a = 0; a < ni; ++a) {
		//VVAdd(accumulator[k][a], w[a]);
		accumulator[k][a] += w[a];
	}
	/****************************************
	if (naccumulator[k] == 0)
	{
		for (unsigned int a = 0; a < ni; ++a)
		{
			//VVAdd(accumulator[k][a], w[a]);
			accumulator[k][a] += w[a];
		}
	}
	/****************************************/
	++naccumulator[k];
	if (naccumulator[k] == m) {
		/******************************************************/
		for (unsigned int a = 0; a < ni; ++a) {
			//VSCopy(accumulator[k][a], 1 / m, accumulator[k][a]);
			//accumulator[k][a].x = accumulator[k][a].x / ((double)m);
			//accumulator[k][a].y = accumulator[k][a].y / ((double)m);
			//accumulator[k][a].z = accumulator[k][a].z / ((double)m);
			accumulator[k][a] = accumulator[k][a] / ((double)m);
		}
		/******************************************************/
		add(accumulator[k], k + 1);
		for (unsigned int a = 0; a < ni; ++a) {
			//VSet(accumulator[k][a], 0, 0, 0);
			accumulator[k][a] = 0;
		}
		naccumulator[k] = 0;
	}

	/// Calculate correlation function
	unsigned int ind1 = insertindex[k];
	if (k == 0) { /// First correlator is different
		int ind2 = ind1;
		for (unsigned int j = 0; j < p; ++j) {
			for (unsigned int a = 0; a < ni; ++a) {
				//if (shift[k][ind2][a].x > -1E10&&shift[k][ind2][a].y > -1E10&&shift[k][ind2][a].z > -1E10)
				if (shift[k][ind2][a] > -1E10)
				{
					//VSub(dr, shift[k][ind2][a], shift[k][ind1][a]);
					//correlation[k][j] += VLenSq(dr);
					//correlation[k][j] += shift[k][ind2][a].x*shift[k][ind1][a].x + shift[k][ind2][a].y*shift[k][ind1][a].y + shift[k][ind2][a].z*shift[k][ind1][a].z;
					correlation[k][j] += shift[k][ind2][a] * shift[k][ind1][a];
					++ncorrelation[k][j];
				}
			}
			--ind2;
			if (ind2 < 0) ind2 += p;
		}
	}
	else {
		int ind2 = ind1 - dmin;
		for (unsigned int j = dmin; j < p; ++j) {
			if (ind2 < 0) ind2 += p;
			for (unsigned int a = 0; a < ni; ++a) {
				//if (shift[k][ind2][a].x > -1E10&&shift[k][ind2][a].y > -1E10&&shift[k][ind2][a].z > -1E10) 
				if (shift[k][ind2][a] > -1E10)
				{
					//VSub(dr, shift[k][ind2][a], shift[k][ind1][a]);
					//correlation[k][j] += VLenSq(dr);
					//correlation[k][j] += shift[k][ind2][a].x*shift[k][ind1][a].x + shift[k][ind2][a].y*shift[k][ind1][a].y + shift[k][ind2][a].z*shift[k][ind1][a].z;
					correlation[k][j] += shift[k][ind2][a] * shift[k][ind1][a];
					++ncorrelation[k][j];
				}
			}
			--ind2;
		}
	}

	++insertindex[k];
	if (insertindex[k] == p) insertindex[k] = 0;

}


void FCorrelator::evaluate(const bool norm) {
	unsigned int im = 0;

	/***************
	double aux = 0;

	if (norm) {
		aux = (accval.x / ncorrelation[0][0])*(accval.x / ncorrelation[0][0]) + \
				  (accval.y / ncorrelation[0][0])*(accval.y / ncorrelation[0][0]) + \
				  (accval.z / ncorrelation[0][0])*(accval.z / ncorrelation[0][0]);
	}
	/***************/

	/// First correlator
	for (unsigned int i = 0; i < p; ++i) {
		if (ncorrelation[0][i] > 0) {
			t[im] = i;
			f[im] = correlation[0][i] / ncorrelation[0][i]; // -aux;
			++im;
		}
	}

	// Subsequent correlators
	/***********************************************/
	for (unsigned int k = 1; k < kmax; ++k) {
		for (unsigned int i = dmin; i < p; ++i) {
			if (ncorrelation[k][i] > 0) {
				t[im] = i * pow((double)m, k);
				f[im] = correlation[k][i] / ncorrelation[k][i];
				++im;
			}
		}
	}
	/***********************************************
	for (int k = 1; k < kmax; ++k) {
		for (int i = dmin; i < p; ++i) {
			if (ncorrelation[k][i] > 0) {
				t[im] = i * pow((double)m, k);
				f[im] = correlation[k][i] / ncorrelation[k][i];
				++im;
			}
		}
	}
	/***********************************************/


	npcorr = im;

}

FCorrelatorMSD::FCorrelatorMSD(const unsigned int numcorrin, const unsigned int pin, const unsigned int min, unsigned int ninput) {
	setsize(numcorrin, pin, min, ninput);
}

FCorrelatorMSD::~FCorrelatorMSD() {
	if (numcorrelators == 0) return;

	delete[] shift;
	delete[] correlation;
	delete[] ncorrelation;
	delete[] accumulator;
	delete[] naccumulator;
	delete[] insertindex;

	delete[] t;
	delete[] f;

}

void FCorrelatorMSD::setsize(const unsigned int numcorrin, const unsigned int pin, const unsigned int min, unsigned int ninput) {
	numcorrelators = numcorrin;
	p = pin;
	m = min;
	dmin = p / m;

	ni = ninput;
	flkVecR *w = new flkVecR[ni];

	length = numcorrelators * p;
	shift = new flkVecR**[numcorrelators];
	correlation = new double*[numcorrelators];
	ncorrelation = new unsigned long int *[numcorrelators];
	accumulator = new flkVecR*[numcorrelators];
	naccumulator = new unsigned int[numcorrelators];
	insertindex = new unsigned int[numcorrelators];

	accval = new flkVecR[ni];

	for (unsigned int j = 0; j < numcorrelators; ++j) {
		shift[j] = new flkVecR*[p];
		for (unsigned int i = 0; i < p; ++i) {
			shift[j][i] = new flkVecR[ni];
		}

		accumulator[j] = new flkVecR[ni];
		/* It can be optimized: Apart from correlator 0, correlation and ncorrelation arrays only use p/2 values */
		correlation[j] = new double[p];
		ncorrelation[j] = new unsigned long int[p];
	}

	t = new double[length];
	f = new double[length];
}

void FCorrelatorMSD::initialize() {
	for (unsigned int j = 0; j < numcorrelators; ++j) {
		for (unsigned int i = 0; i < p; ++i) {
			for (unsigned int k = 0; k < ni; ++k) {
				flkVSet(shift[j][i][k], -2E10, -2E10, -2E10);
			}
			correlation[j][i] = 0.0;
			ncorrelation[j][i] = 0;
		}
		for (unsigned int a = 0; a < ni; ++a) {
			flkVSet(accumulator[j][a], 0.0, 0.0, 0.0);
		}

		naccumulator[j] = 0;
		insertindex[j] = 0;
	}

	for (unsigned int i = 0; i < length; ++i) {
		t[i] = 0.0;
		f[i] = 0.0;
	}

	npcorr = 0;
	kmax = 0;
	for (unsigned int i = 0; i < ni; ++i) {
		flkVSet(accval[i], 0.0, 0.0, 0.0);
	}

}

void FCorrelatorMSD::add(flkVecR *w, const unsigned int k) {
	/// If we exceed the correlator side, the value is discarded
	if (k == numcorrelators) return;
	if (k > kmax) kmax = k;

	/// Insert new value in shift array
	for (unsigned int i = 0; i < ni; ++i) {
		flkVCopy(shift[k][insertindex[k]][i], w[i]);
	}

	/// Add to aveage value
	if (k == 0) {
		for (unsigned int a = 0; a < ni; ++a) {
			flkVVAdd(accval[a], w[a]);
		}
	}


	/// Add to accumulator and, if needed, add to next correlator
	/****************************************
	for (unsigned int a = 0; a < nMID; ++a) {
		VVAdd(accumulator[k][a], w[a]);
	}
	/****************************************/
	if (naccumulator[k] == 0)
	{
		for (unsigned int a = 0; a < ni; ++a)
		{
			flkVCopy(accumulator[k][a], w[a]);
		}
	}

	++naccumulator[k];
	if (naccumulator[k] == m) {
		/******************************************************
		for (unsigned int a = 0; a < nMID; ++a) {
			VSCopy(accumulator[k][a], 1 / m, accumulator[k][a]);
		}
		/******************************************************/
		add(accumulator[k], k + 1);
		for (unsigned int a = 0; a < ni; ++a) {
			flkVSet(accumulator[k][a], 0, 0, 0);
		}
		naccumulator[k] = 0;
	}

	/// Calculate correlation function
	unsigned int ind1 = insertindex[k];
	if (k == 0) { /// First correlator is different
		int ind2 = ind1;
		for (unsigned int j = 0; j < p; ++j) {
			for (unsigned int a = 0; a < ni; ++a) {
				if (shift[k][ind2][a].x > -1E10&&shift[k][ind2][a].y > -1E10&&shift[k][ind2][a].z > -1E10) {
					flkVSub(dr, shift[k][ind2][a], shift[k][ind1][a]);
					correlation[k][j] += flkVLenSq(dr);
					++ncorrelation[k][j];
				}
			}
			--ind2;
			if (ind2 < 0) ind2 += p;
		}
	}
	else {
		int ind2 = ind1 - dmin;
		for (unsigned int j = dmin; j < p; ++j) {
			if (ind2 < 0) ind2 += p;
			for (unsigned int a = 0; a < ni; ++a) {
				if (shift[k][ind2][a].x > -1E10&&shift[k][ind2][a].y > -1E10&&shift[k][ind2][a].z > -1E10) {
					flkVSub(dr, shift[k][ind2][a], shift[k][ind1][a]);
					correlation[k][j] += flkVLenSq(dr);
					++ncorrelation[k][j];
				}
			}
			--ind2;
		}
	}

	++insertindex[k];
	if (insertindex[k] == p) insertindex[k] = 0;

}


void FCorrelatorMSD::evaluate(const bool norm) {
	unsigned int im = 0;

	/***************
	double aux = 0;

	if (norm) {
		aux = (accval.x / ncorrelation[0][0])*(accval.x / ncorrelation[0][0]) + \
				  (accval.y / ncorrelation[0][0])*(accval.y / ncorrelation[0][0]) + \
				  (accval.z / ncorrelation[0][0])*(accval.z / ncorrelation[0][0]);
	}
	/***************/

	/// First correlator
	for (unsigned int i = 0; i < p; ++i) {
		if (ncorrelation[0][i] > 0) {
			t[im] = i;
			f[im] = correlation[0][i] / ncorrelation[0][i]; // -aux;
			++im;
		}
	}

	// Subsequent correlators
	/***********************************************/
	for (unsigned int k = 1; k < kmax; ++k) {
		for (unsigned int i = dmin; i < p; ++i) {
			if (ncorrelation[k][i] > 0) {
				t[im] = i * pow((double)m, k);
				f[im] = correlation[k][i] / ncorrelation[k][i];
				++im;
			}
		}
	}
	/***********************************************
	for (int k = 1; k < kmax; ++k) {
		for (int i = dmin; i < p; ++i) {
			if (ncorrelation[k][i] > 0) {
				t[im] = i * pow((double)m, k);
				f[im] = correlation[k][i] / ncorrelation[k][i];
				++im;
			}
		}
	}
	/***********************************************/


	npcorr = im;

}



FCorrelatorACF::FCorrelatorACF(const unsigned int numcorrin, const unsigned int pin, const unsigned int min, unsigned int ninput) {
	setsize(numcorrin, pin, min, ninput);
}

FCorrelatorACF::~FCorrelatorACF() {
	if (numcorrelators == 0) return;

	delete[] shift;
	delete[] correlation;
	delete[] ncorrelation;
	delete[] accumulator;
	delete[] naccumulator;
	delete[] insertindex;

	delete[] t;
	delete[] f;

}



void FCorrelatorACF::setsize(const unsigned int numcorrin, const unsigned int pin, const unsigned int min, unsigned int ninput) {
	numcorrelators = numcorrin;
	p = pin;
	m = min;
	dmin = p / m;

	ni = ninput;
	flkVecR *w = new flkVecR[ni];

	length = numcorrelators * p;
	shift = new flkVecR**[numcorrelators];
	correlation = new double*[numcorrelators];
	ncorrelation = new unsigned long int *[numcorrelators];
	accumulator = new flkVecR*[numcorrelators];
	naccumulator = new unsigned int[numcorrelators];
	insertindex = new unsigned int[numcorrelators];

	accval = new flkVecR[ni];

	for (unsigned int j = 0; j < numcorrelators; ++j) {
		shift[j] = new flkVecR*[p];
		for (unsigned int i = 0; i < p; ++i) {
			shift[j][i] = new flkVecR[ni];
		}

		accumulator[j] = new flkVecR[ni];
		/* It can be optimized: Apart from correlator 0, correlation and ncorrelation arrays only use p/2 values */
		correlation[j] = new double[p];
		ncorrelation[j] = new unsigned long int[p];
	}

	t = new double[length];
	f = new double[length];
}

void FCorrelatorACF::initialize() {
	for (unsigned int j = 0; j < numcorrelators; ++j) {
		for (unsigned int i = 0; i < p; ++i) {
			for (unsigned int k = 0; k < ni; ++k) {
				flkVSet(shift[j][i][k], -2E10, -2E10, -2E10);
			}
			correlation[j][i] = 0.0;
			ncorrelation[j][i] = 0;
		}
		for (unsigned int a = 0; a < ni; ++a) {
			flkVSet(accumulator[j][a], 0.0, 0.0, 0.0);
		}

		naccumulator[j] = 0;
		insertindex[j] = 0;
	}

	for (unsigned int i = 0; i < length; ++i) {
		t[i] = 0.0;
		f[i] = 0.0;
	}

	npcorr = 0;
	kmax = 0;
	for (unsigned int i = 0; i < ni; ++i) {
		flkVSet(accval[i], 0.0, 0.0, 0.0);
	}

}



void FCorrelatorACF::add(flkVecR *w, const unsigned int k) {
	/// If we exceed the correlator side, the value is discarded
	if (k == numcorrelators) return;
	if (k > kmax) kmax = k;

	/// Insert new value in shift array
	for (unsigned int i = 0; i < ni; ++i) {
		flkVCopy(shift[k][insertindex[k]][i], w[i]);
	}

	/// Add to aveage value
	if (k == 0) {
		for (unsigned int a = 0; a < ni; ++a) {
			flkVVAdd(accval[a], w[a]);
		}
	}


	/// Add to accumulator and, if needed, add to next correlator
	/****************************************
	for (unsigned int a = 0; a < nMID; ++a) {
		VVAdd(accumulator[k][a], w[a]);
	}
	/****************************************/
	if (naccumulator[k] == 0)
	{
		for (unsigned int a = 0; a < ni; ++a)
		{
			flkVCopy(accumulator[k][a], w[a]);
		}
	}

	++naccumulator[k];
	if (naccumulator[k] == m) {
		/******************************************************
		for (unsigned int a = 0; a < nMID; ++a) {
			VSCopy(accumulator[k][a], 1 / m, accumulator[k][a]);
		}
		/******************************************************/
		add(accumulator[k], k + 1);
		for (unsigned int a = 0; a < ni; ++a) {
			flkVSet(accumulator[k][a], 0, 0, 0);
		}
		naccumulator[k] = 0;
	}

	/// Calculate correlation function
	unsigned int ind1 = insertindex[k];
	if (k == 0) { /// First correlator is different
		int ind2 = ind1;
		for (unsigned int j = 0; j < p; ++j) {
			for (unsigned int a = 0; a < ni; ++a) {
				if (shift[k][ind2][a].x > -1E10&&shift[k][ind2][a].y > -1E10&&shift[k][ind2][a].z > -1E10) {
					//flkVSub(dr, shift[k][ind2][a], shift[k][ind1][a]);
					//correlation[k][j] += flkVLenSq(dr);

					correlation[k][j] += shift[k][ind2][a].x*shift[k][ind1][a].x + shift[k][ind2][a].y*shift[k][ind1][a].y + shift[k][ind2][a].z*shift[k][ind1][a].z;


					++ncorrelation[k][j];
				}
			}
			--ind2;
			if (ind2 < 0) ind2 += p;
		}
	}
	else {
		int ind2 = ind1 - dmin;
		for (unsigned int j = dmin; j < p; ++j) {
			if (ind2 < 0) ind2 += p;
			for (unsigned int a = 0; a < ni; ++a) {
				if (shift[k][ind2][a].x > -1E10&&shift[k][ind2][a].y > -1E10&&shift[k][ind2][a].z > -1E10) {
					//flkVSub(dr, shift[k][ind2][a], shift[k][ind1][a]);
					//correlation[k][j] += flkVLenSq(dr);

					correlation[k][j] += shift[k][ind2][a].x*shift[k][ind1][a].x + shift[k][ind2][a].y*shift[k][ind1][a].y + shift[k][ind2][a].z*shift[k][ind1][a].z;

					++ncorrelation[k][j];
				}
			}
			--ind2;
		}
	}

	++insertindex[k];
	if (insertindex[k] == p) insertindex[k] = 0;

}


void FCorrelatorACF::evaluate(const bool norm) {
	unsigned int im = 0;

	/***************
	double aux = 0;

	if (norm) {
		aux = (accval.x / ncorrelation[0][0])*(accval.x / ncorrelation[0][0]) + \
				  (accval.y / ncorrelation[0][0])*(accval.y / ncorrelation[0][0]) + \
				  (accval.z / ncorrelation[0][0])*(accval.z / ncorrelation[0][0]);
	}
	/***************/

	/// First correlator
	for (unsigned int i = 0; i < p; ++i) {
		if (ncorrelation[0][i] > 0) {
			t[im] = i;
			f[im] = correlation[0][i] / ncorrelation[0][i]; // -aux;
			++im;
		}
	}

	// Subsequent correlators
	/***********************************************/
	for (unsigned int k = 1; k < kmax; ++k) {
		for (unsigned int i = dmin; i < p; ++i) {
			if (ncorrelation[k][i] > 0) {
				t[im] = i * pow((double)m, k);
				f[im] = correlation[k][i] / ncorrelation[k][i];
				++im;
			}
		}
	}
	/***********************************************
	for (int k = 1; k < kmax; ++k) {
		for (int i = dmin; i < p; ++i) {
			if (ncorrelation[k][i] > 0) {
				t[im] = i * pow((double)m, k);
				f[im] = correlation[k][i] / ncorrelation[k][i];
				++im;
			}
		}
	}
	/***********************************************/


	npcorr = im;

}


































































